package com.example.blank;
import android.content.Intent;
import android.graphics.drawable.AnimationDrawable;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

public class SecondActivity extends AppCompatActivity {

    String gender;
    int age;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            gender = extras.getString("gender");
            age = extras.getInt("age");
        }

        ImageButton happy = findViewById(R.id.happy);
        ImageButton bored = findViewById(R.id.bored);
        ImageButton sad = findViewById(R.id.sad);
        ImageButton angry = findViewById(R.id.angry);

        happy.setOnClickListener(new View.OnClickListener() {
            final String emotion = "happy";
            @Override
            public void onClick(View v) {
                Intent i = new Intent(SecondActivity.this, QuotesActivity.class);
                i.putExtra("age",age);
                i.putExtra("gender",gender);
                i.putExtra("emotion",emotion);
                startActivity(i);
            }
        });

        sad.setOnClickListener(new View.OnClickListener() {
            final String emotion = "sad";
            @Override
            public void onClick(View v) {
                Intent i = new Intent(SecondActivity.this, NotesActivity.class);
                i.putExtra("age",age);
                i.putExtra("gender",gender);
                i.putExtra("emotion",emotion);
                startActivity(i);
            }
        });

        angry.setOnClickListener(new View.OnClickListener() {
            final String emotion = "angry";
            @Override
            public void onClick(View v) {
                Intent i = new Intent(SecondActivity.this, BreatheActivity.class);
                i.putExtra("age",age);
                i.putExtra("gender",gender);
                i.putExtra("emotion",emotion);
                startActivity(i);
            }
        });

        bored.setOnClickListener(new View.OnClickListener() {
            final String emotion = "bored";
            @Override
            public void onClick(View v) {
                Intent i = new Intent(SecondActivity.this, MeditationActivity.class);
                i.putExtra("age",age);
                i.putExtra("gender",gender);
                i.putExtra("emotion",emotion);
                startActivity(i);
            }
        });
    }
}