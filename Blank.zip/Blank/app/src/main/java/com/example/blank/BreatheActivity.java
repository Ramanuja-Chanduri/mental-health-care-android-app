package com.example.blank;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.animation.Animator;
import android.animation.ObjectAnimator;
import android.content.Intent;
import android.graphics.drawable.AnimationDrawable;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.util.Log;
import android.view.View;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;

public class BreatheActivity extends AppCompatActivity {

    String gender;
    int age;
    String emotion;
    static MediaPlayer music;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_breathe);
        ConstraintLayout layout = findViewById(R.id.layout);
        AnimationDrawable animationDrawable = (AnimationDrawable) layout.getBackground();
        animationDrawable.setEnterFadeDuration(1500);
        animationDrawable.setExitFadeDuration(3000);
        animationDrawable.start();

        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            gender = extras.getString("gender");
            age = extras.getInt("age");
            emotion = extras.getString("emotion");
        }

        Button restart = findViewById(R.id.restart);
        Button cancel = findViewById(R.id.cancel);
        TextView timer = findViewById(R.id.timer);
        ProgressBar progressBar = findViewById(R.id.progressBar);

        runProgram(progressBar,timer);
        music = MediaPlayer.create(BreatheActivity.this, R.raw.music30s);
        music.start();

        restart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                music.stop();
                runProgram(progressBar,timer);
                music = MediaPlayer.create(BreatheActivity.this, R.raw.music30s);
                music.start();
            }
        });

        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                music.stop();
                Intent i = new Intent(BreatheActivity.this, SecondActivity.class);
                i.putExtra("age",age);
                i.putExtra("gender",gender);
                i.putExtra("emotion",emotion);
                startActivity(i);
            }
        });
    }



    public static void runProgram(ProgressBar progressBar, TextView timer) {
        ObjectAnimator animation = ObjectAnimator.ofInt(progressBar, "progress", 0, 100);
        animation.setDuration(30000);
        animation.setInterpolator(new DecelerateInterpolator());
        animation.addListener(new Animator.AnimatorListener() {
            @Override
            public void onAnimationStart(Animator animator) { }

            @Override
            public void onAnimationEnd(Animator animator) { }

            @Override
            public void onAnimationCancel(Animator animation) { }

            @Override
            public void onAnimationRepeat(Animator animation) { }

        }); animation.start();

        new CountDownTimer(30000, 1000){
            int counter = 30;
            public void onTick(long millisUntilFinished){
                counter--;
                timer.setText(String.valueOf(counter));
            }
            public  void onFinish(){ }
        }.start();
    }
}