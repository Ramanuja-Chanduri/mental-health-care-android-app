package com.example.blank;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.content.Intent;
import android.graphics.drawable.AnimationDrawable;
import android.os.Bundle;
import android.text.method.ScrollingMovementMethod;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Scroller;

public class NotesActivity extends AppCompatActivity {
    String gender;
    int age;
    String emotion;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notes);
        ConstraintLayout layout = findViewById(R.id.layout);
        AnimationDrawable animationDrawable = (AnimationDrawable) layout.getBackground();
        animationDrawable.setEnterFadeDuration(1500);
        animationDrawable.setExitFadeDuration(3000);
        animationDrawable.start();

        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            gender = extras.getString("gender");
            age = extras.getInt("age");
            emotion = extras.getString("emotion");
        }

        EditText diary = findViewById(R.id.edit_text);
        Button clear = findViewById(R.id.clear);
        Button cancel = findViewById(R.id.cancel);

        diary.setScroller(new Scroller(NotesActivity.this));
        diary.setMaxLines(15);
        diary.setVerticalScrollBarEnabled(true);
        diary.setMovementMethod(new ScrollingMovementMethod());

        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(NotesActivity.this, SecondActivity.class);
                i.putExtra("age",age);
                i.putExtra("gender",gender);
                i.putExtra("emotion",emotion);
                startActivity(i);
            }
        });

        clear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                diary.setText("");
            }
        });
    }
}