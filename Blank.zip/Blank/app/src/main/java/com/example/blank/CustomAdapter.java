package com.example.blank;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;


public class CustomAdapter extends BaseAdapter {
    private final Context context;
    private final String[] activity;
    private final int[] picture;
    private final String[] descriptions;

    public CustomAdapter(Context context, String[] names, int[] img, String[] descriptions) {
        this.context = context;
        this.activity = names;
        this.picture = img;
        this.descriptions = descriptions;
    }

    @Override
    public int getCount() {
        return activity.length;
    }

    @Override
    public Object getItem(int i) {
        return activity[i];
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        if (view == null) {
            view = LayoutInflater.from(context).inflate(R.layout.listview_items, viewGroup, false);
        }
        ImageView iv = view.findViewById(R.id.imgList);
        TextView tv = view.findViewById(R.id.textList1);
        TextView des = view.findViewById(R.id.textList2);
        des.setText(descriptions[i]);
        iv.setImageResource(picture[i]);
        tv.setText(activity[i]);
        return view;
    }
}

