package com.example.blank;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.content.Intent;
import android.graphics.drawable.AnimationDrawable;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;

public class MeditationActivity extends AppCompatActivity {

    String gender;
    int age;
    String emotion;
    ListView lv;
    String[] headings = {"exercise 1","exercise 2","exercise 3","exercise 4","exercise 5","exercise 6","exercise 7","exercise 8","exercise 9"};
    String[] descriptions = {"this is a dummy description",
            "this is a dummy description redirects me into a youtube guided exercise",
            "this is a dummy description",
            "this is a dummy description",
            "this is a dummy description",
            "this is a dummy description",
            "this is a dummy description",
            "this is a dummy description",
            "this is a dummy description"};
    int[] img = {R.drawable.smile, R.drawable.smile, R.drawable.smile, R.drawable.smile, R.drawable.smile, R.drawable.smile, R.drawable.smile, R.drawable.smile, R.drawable.smile};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_meditation);
        ConstraintLayout layout = findViewById(R.id.layout);
        AnimationDrawable animationDrawable = (AnimationDrawable) layout.getBackground();
        animationDrawable.setEnterFadeDuration(1500);
        animationDrawable.setExitFadeDuration(3000);
        animationDrawable.start();

        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            gender = extras.getString("gender");
            age = extras.getInt("age");
            emotion = extras.getString("emotion");
        }

        Button cancel = findViewById(R.id.cancel);

        lv = findViewById(R.id.quotes);
        CustomAdapter customAdapter = new CustomAdapter(this, headings, img, descriptions);
        lv.setAdapter(customAdapter);


        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MeditationActivity.this, SecondActivity.class);
                i.putExtra("age",age);
                i.putExtra("gender",gender);
                i.putExtra("emotion",emotion);
                startActivity(i);
            }
        });

    }
}