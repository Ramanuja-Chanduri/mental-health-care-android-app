package com.example.blank;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.content.Intent;
import android.graphics.drawable.AnimationDrawable;
import android.os.Bundle;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.Arrays;
import java.util.Random;

public class QuotesActivity extends AppCompatActivity {
    String gender;
    int age;
    String emotion;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quotes);
        ConstraintLayout layout = findViewById(R.id.layout);
        AnimationDrawable animationDrawable = (AnimationDrawable) layout.getBackground();
        animationDrawable.setEnterFadeDuration(1500);
        animationDrawable.setExitFadeDuration(3000);
        animationDrawable.start();

        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            gender = extras.getString("gender");
            age = extras.getInt("age");
            emotion = extras.getString("emotion");
        }

        TextView tap = findViewById(R.id.tap);
        TextView quote = findViewById(R.id.quote);
        Button cancel = findViewById(R.id.cancel);

        String[] quotes_sad = getResources().getStringArray(R.array.quotes_sad);
        String[] quotes_motivational = getResources().getStringArray(R.array.quotes_motivational);
        String[] quotes_anxiety = getResources().getStringArray(R.array.quotes_anxiety);
        String[] quotes_fear = getResources().getStringArray(R.array.quotes_fear);

        String[] sadMot = Arrays.copyOf(quotes_sad, quotes_sad.length + quotes_motivational.length);
        System.arraycopy(quotes_motivational, 0, sadMot, quotes_sad.length, quotes_motivational.length);
        String[] anxFea = Arrays.copyOf(quotes_anxiety, quotes_anxiety.length + quotes_fear.length);
        System.arraycopy(quotes_fear, 0, sadMot, quotes_anxiety.length, quotes_fear.length);

        String[] arr = Arrays.copyOf(sadMot, sadMot.length + anxFea.length);
        System.arraycopy(anxFea, 0, arr, sadMot.length, anxFea.length);

        layout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Random random = new Random();
                int index = random.nextInt(arr.length - 1);
                quote.setText(arr[index]);
                tap.setText("");
            }
        });

        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(QuotesActivity.this, SecondActivity.class);
                i.putExtra("age",age);
                i.putExtra("gender",gender);
                i.putExtra("emotion",emotion);
                startActivity(i);
            }
        });
    }
}